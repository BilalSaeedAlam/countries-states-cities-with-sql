"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("states", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      name: {
        allowNull: false,
        type: Sequelize.STRING,
      },
      country_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: "countries",
          key: "id",
        },
      },
      status: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
        comment: "true - Active | false - Inactive",
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    // Drop the states table
    await queryInterface.dropTable("states");
  },
};
