"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("countries", {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      iso3: {
        type: Sequelize.STRING(3),
        allowNull: false,
      },
      iso2: {
        type: Sequelize.STRING(2),
        allowNull: false,
      },
      numeric_code: {
        type: Sequelize.STRING(3),
        allowNull: false,
      },
      phone_code: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      capital: {
        type: Sequelize.STRING,
        allowNull: false,
      },
      currency: {
        type: Sequelize.STRING,
        allowNull: false,
      },

      status: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
        comment: "true - Active | false - Inactive",
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    // Drop the countries table
    await queryInterface.dropTable("countries");
  },
};
