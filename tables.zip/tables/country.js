"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Country extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Country.hasMany(models.State, {
        foreignKey: "country_id",
        as: "states",
      });
    }
  }
  Country.init(
    {
      id: {
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      iso3: {
        type: DataTypes.STRING(3),
        allowNull: false,
      },
      iso2: {
        type: DataTypes.STRING(2),
        allowNull: false,
      },
      numeric_code: {
        type: DataTypes.STRING(3),
        allowNull: false,
      },
      phone_code: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      capital: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      currency: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      status: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        comment: "true - Active | false - Inactive",
      },
    },
    {
      sequelize,
      modelName: "Country",
      tableName: "countries",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
    }
  );
  return Country;
};
