"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class State extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      State.belongsTo(models.Country, {
        foreignKey: "country_id",
        as: "country",
      });
      State.hasMany(models.City, {
        foreignKey: "state_id",
        as: "cities",
      });
    }
  }
  State.init(
    {
      id: {
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER,
      },
      name: {
        allowNull: false,
        type: DataTypes.STRING,
      },
      country_id: {
        allowNull: false,
        type: DataTypes.INTEGER,
        references: {
          model: "countries",
          key: "id",
        },
      },
      status: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        comment: "true - Active | false - Inactive",
      },
    },
    {
      sequelize,
      modelName: "State",
      tableName: "states",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
    }
  );
  return State;
};
